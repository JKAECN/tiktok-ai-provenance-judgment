# ==============================================================================
# AI PROVENANCE STUDY — V3.5.5
# Direct AI-Provenance High-Recall Retrieval + Human Confirmation Pipeline
#
# Rationale:
# V3.4 showed that the broad "general provenance" task was internally
# heterogeneous. In the 19 human-confirmed positives found by the negative
# recall audit, only 1 was AI-provenance; the rest were mostly editing/filter,
# broad-fake, or general authenticity/production talk.
#
# V3.5 therefore aligns measurement with the paper's substantive target:
#
#   HUMAN GOLD (AI provenance vs all other comments)
#       -> grouped OOF high-recall retrieval
#       -> word 1–2 gram + character 3–5 gram + structured lexical features
#       -> full-corpus AI candidate retrieval
#       -> HUMAN REVIEW of every new candidate
#       -> stratified HUMAN AUDIT of predicted negatives
#       -> final human-confirmed AI corpus
#       -> stance / reason / concentration / co-occurrence / interaction models
#
# IMPORTANT:
# - Machine learning is used as a RETRIEVAL device, not as final annotation.
# - All comments entering the core AI-provenance analyses are human-confirmed.
# - Likes/replies are interactional uptake, not belief/persuasion.
# - Local concentration is not contagion.
# - Co-occurrence is not a reply relation.
# ==============================================================================

rm(list = ls())
gc()

options(stringsAsFactors = FALSE)
options(datatable.print.nrows = 50)

pkg_needed <- c(
  "data.table", "quanteda", "glmnet", "Matrix",
  "stringi", "stringr", "lubridate",
  "fixest", "ggplot2", "broom", "scales"
)

for (p in pkg_needed) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, dependencies = TRUE)
  }
}

suppressPackageStartupMessages({
  library(data.table)
  library(quanteda)
  library(glmnet)
  library(Matrix)
  library(stringi)
  library(stringr)
  library(lubridate)
  library(fixest)
  library(ggplot2)
  library(broom)
  library(scales)
})

CFG <- list(
  seed = 20261022L,

  output_dir = "AI_Provenance_V3_5_outputs",
  previous_output_dir = "AI_Provenance_V3_4_outputs",
  v3_output_dir = "AI_Provenance_V3_outputs",
  v2_output_dir = "AI_Provenance_V2_outputs",

  primary_language = "en",
  include_unknown_language_in_main = TRUE,

  # Retrieval model.
  folds = 5L,
  alpha = 0.5,
  max_word_features = 25000L,
  max_char_features = 40000L,
  prediction_chunk = 20000L,

  # The model is a retrieval device. We prioritize recall.
  target_recall = 0.90,
  min_precision_for_retrieval = 0.25,

  # Candidate-review burden control.
  max_new_candidates_for_full_review = 12000L,

  # Predicted-negative audit.
  # V3.5.5 uses mutually exclusive lexical-risk strata rather than fractions
  # of the model threshold, because most predicted negatives receive nearly
  # identical low model probabilities.
  negative_audit_soft_ai_n = 500L,
  negative_audit_production_n = 500L,
  negative_audit_baseline_n = 1000L,

  # After completed negative audit, estimated final retrieval recall must be
  # adequate before inferential analyses proceed.
  min_estimated_final_recall = 0.90,

  # Final permutation analyses.
  permutations = 10000L,

  # Interaction models.
  min_comments_per_video_fe = 2L,
  run_interaction_models = TRUE,

  # Cache.
  reuse_prediction_cache = TRUE
)

dir.create(CFG$output_dir, recursive = TRUE, showWarnings = FALSE)
set.seed(CFG$seed)

# ==============================================================================
# 1. LOAD PRELABELLED COMMENT CACHE
# ==============================================================================

cache_candidates <- unique(c(
  file.path(CFG$output_dir, "comments_prelabelled_v3.rds"),
  file.path(CFG$previous_output_dir, "comments_prelabelled_v3.rds"),
  file.path(CFG$v3_output_dir, "comments_prelabelled_v3.rds"),
  file.path(CFG$v3_output_dir, "comments_coded_v2.rds"),
  file.path(CFG$v2_output_dir, "comments_prelabelled_v3.rds"),
  file.path(CFG$v2_output_dir, "comments_coded_v2.rds")
))
cache_candidates <- cache_candidates[file.exists(cache_candidates)]

if (!length(cache_candidates)) {
  stop(
    "\nV3.5 requires the existing parsed/prelabelled comment cache.\n",
    "Expected one of:\n",
    "  AI_Provenance_V3_outputs/comments_prelabelled_v3.rds\n",
    "  AI_Provenance_V2_outputs/comments_coded_v2.rds\n",
    "Do NOT re-annotate. Restore one of those cache files and rerun."
  )
}

cache_path <- cache_candidates[1]
comments <- readRDS(cache_path)
setDT(comments)

message(
  "[1/10] Loaded comment cache: ", cache_path,
  " | n = ", format(nrow(comments), big.mark = ",")
)

# Defensive types.
comments[, source_row := as.integer(source_row)]
comments[, comment_key := as.character(comment_key)]
comments[, video_id := as.character(video_id)]
comments[, text := fifelse(is.na(text), "", as.character(text))]
comments[, description := fifelse(is.na(description), "", as.character(description))]

# ==============================================================================
# 2. LOAD HUMAN GOLD STANDARD
# ==============================================================================

gold_candidates <- unique(c(
  file.path(CFG$output_dir, "HUMAN_ADJUDICATED_FINAL.csv"),
  file.path(CFG$previous_output_dir, "HUMAN_ADJUDICATED_FINAL.csv"),
  file.path(CFG$v3_output_dir, "HUMAN_ADJUDICATED_FINAL.csv"),
  file.path(CFG$v2_output_dir, "HUMAN_ADJUDICATED_FINAL.csv"),
  file.path(getwd(), "HUMAN_ADJUDICATED_FINAL.csv"),
  list.files(
    ".",
    pattern = "^HUMAN_ADJUDICATED_FINAL\\.csv$",
    full.names = TRUE,
    recursive = TRUE
  )
))
gold_candidates <- gold_candidates[file.exists(gold_candidates)]

if (!length(gold_candidates)) {
  stop(
    "\nCannot find HUMAN_ADJUDICATED_FINAL.csv.\n",
    "Use the already-completed 4,302-row adjudicated gold file. ",
    "Do not re-code the sample."
  )
}

gold_path <- gold_candidates[1]
gold <- fread(gold_path, encoding = "UTF-8")
setDT(gold)

required_gold <- c(
  "comment_key",
  "source_row",
  "provenance_relevant_final",
  "technology_final",
  "stance_final",
  "primary_reason_final",
  "reason_type_final",
  "validation_stratum"
)

miss_gold <- setdiff(required_gold, names(gold))
if (length(miss_gold)) {
  stop(
    "Gold file is missing required columns: ",
    paste(miss_gold, collapse = ", ")
  )
}

gold[, comment_key := as.character(comment_key)]
gold[, source_row := as.integer(source_row)]
gold[, provenance_relevant_final := as.integer(provenance_relevant_final)]
gold[, technology_final := as.character(technology_final)]
gold[, stance_final := as.character(stance_final)]
gold[, primary_reason_final := as.integer(primary_reason_final)]
gold[, reason_type_final := as.character(reason_type_final)]
gold[, validation_stratum := as.character(validation_stratum)]

gold <- gold[!duplicated(comment_key)]

message(
  "[2/10] Human gold detected: ", gold_path,
  " | n = ", nrow(gold)
)

# Direct target: AI provenance vs everything else.
gold[, AI_provenance_gold := fcase(
  provenance_relevant_final == 1L & technology_final == "AI", 1L,
  provenance_relevant_final %in% c(0L, 1L), 0L,
  default = NA_integer_
)]

gold_ai_audit <- gold[
  !is.na(AI_provenance_gold),
  .(
    n = .N,
    AI_positive = sum(AI_provenance_gold == 1L),
    AI_negative = sum(AI_provenance_gold == 0L)
  ),
  by = validation_stratum
]

fwrite(
  gold_ai_audit,
  file.path(CFG$output_dir, "01_AI_gold_by_validation_stratum.csv"),
  bom = TRUE
)

# ==============================================================================
# 3. MAIN-LANGUAGE CORPUS + GOLD MERGE
# ==============================================================================

if (isTRUE(CFG$include_unknown_language_in_main)) {
  comments_main <- comments[
    is.na(comment_language) |
      comment_language == "" |
      tolower(comment_language) == tolower(CFG$primary_language)
  ]
} else {
  comments_main <- comments[
    tolower(comment_language) == tolower(CFG$primary_language)
  ]
}

comments_main[, comment_key := as.character(comment_key)]

# Metadata for the human gold.
meta <- comments_main[, .(
  comment_key,
  source_row_corpus = source_row,
  creator_corpus = as.character(creator),
  comment_text_corpus = text,
  description_corpus = description
)]

gold_ml <- merge(
  gold,
  meta,
  by = "comment_key",
  all.x = TRUE
)

gold_ml[
  !is.na(source_row_corpus),
  source_row := source_row_corpus
]

if ("comment_text" %in% names(gold_ml)) {
  gold_ml[, comment_text_ml := fifelse(
    !is.na(comment_text_corpus),
    comment_text_corpus,
    as.character(comment_text)
  )]
} else {
  gold_ml[, comment_text_ml := fifelse(
    !is.na(comment_text_corpus),
    comment_text_corpus,
    ""
  )]
}

gold_ml[, group_id := fifelse(
  !is.na(creator_corpus) & nzchar(creator_corpus),
  paste0("creator::", creator_corpus),
  paste0("video::", source_row)
)]

gold_ml <- gold_ml[!is.na(AI_provenance_gold)]

message(
  "[3/10] Main-language comments: ",
  format(nrow(comments_main), big.mark = ","),
  " | usable gold: ", nrow(gold_ml),
  " | AI positives: ", sum(gold_ml$AI_provenance_gold == 1L)
)

# ==============================================================================
# 4. TEXT NORMALIZATION + HYBRID FEATURES
# ==============================================================================

normalize_text <- function(x) {
  x <- fifelse(is.na(x), "", as.character(x))
  x <- stringi::stri_trans_nfkc(x)
  x <- stringi::stri_trans_tolower(x)
  x <- stringr::str_replace_all(x, "https?://\\S+|www\\.\\S+", " <url> ")
  x <- stringr::str_replace_all(x, "@[A-Za-z0-9_\\.]+", " <user> ")
  x <- stringr::str_replace_all(x, "\\s+", " ")
  trimws(x)
}


# ------------------------------------------------------------------------------
# Retrieval and audit lexicons
# ------------------------------------------------------------------------------

# Explicit/high-confidence AI provenance retrieval union.
direct_ai_regex <- paste0(
  "(?i)(",
  "\\bai\\b|a\\.i\\.|artificial intelligence|",
  "ai[- ]?generated|generated (by|with) ai|",
  "made (by|with) ai|gen[- ]?ai|aigc|",
  "deep ?fake|deepfake|synthetic (voice|video|image)|",
  "voice clone|cloned voice|",
  "not ai|isn'?t ai|is not ai|no ai|without ai|non[- ]?ai|",
  "human[- ]?made|made by (a )?human|more human",
  ")"
)

# Negative-audit risk stratum 1:
# language that can imply AI/human provenance without matching the explicit union.
soft_ai_risk_regex <- paste0(
  "(?i)(",
  "\\bhuman\\b|\\bmachine\\b|\\bbot\\b|robotic|",
  "generative|generated|generator|synthetic|clone[ds]?|",
  "\\bfake\\b|\\breal\\b|actually real|looks? real|so real|",
  "computer[- ]?made|computer generated|digital[- ]?made|",
  "voiceover|voice over|\\bvoice\\b",
  ")"
)

# Negative-audit risk stratum 2:
# production/provenance language observed among prior false negatives.
production_provenance_regex <- paste0(
  "(?i)(",
  "\\bedit(ed|ing|s)?\\b|capcut|filter(ed|s)?|effect(s)?|",
  "\\bcgi\\b|animation|animated|render(ed|ing)?|",
  "source\\??|original (video|clip|post|upload|source)|",
  "shot on|filmed on|recorded on|camera|",
  "sped ?up|speed ?up|2x speed|slow[- ]?mo|",
  "\\birl\\b|in real life|actually happened|did .* actually",
  ")"
)

gold_ml[, ml_text := normalize_text(comment_text_ml)]

structured_features <- function(text) {
  x <- normalize_text(text)

  data.table(
    sx_ai_token = as.integer(str_detect(
      x,
      "(?i)(^|\\b)(ai|a\\.i\\.|artificial intelligence)(\\b|$)"
    )),
    sx_ai_generated = as.integer(str_detect(
      x,
      "(?i)(ai[- ]?generated|generated (by|with) ai|made (by|with) ai|gen[- ]?ai|aigc)"
    )),
    sx_not_ai = as.integer(str_detect(
      x,
      "(?i)(not ai|isn'?t ai|is not ai|no ai|without ai|non[- ]?ai)"
    )),
    sx_deepfake = as.integer(str_detect(
      x,
      "(?i)(deep ?fake|deepfake)"
    )),
    sx_synthetic = as.integer(str_detect(
      x,
      "(?i)(synthetic|generated|generative)"
    )),
    sx_human = as.integer(str_detect(
      x,
      "(?i)(human[- ]?made|made by (a )?human|real (person|human)|more human|actual human|human art|human artist)"
    )),
    sx_real_fake = as.integer(str_detect(
      x,
      "(?i)(\\breal\\b|\\bfake\\b|actually real|looks? real|so real|irl|in real life)"
    )),
    sx_voice = as.integer(str_detect(
      x,
      "(?i)(ai voice|voice clone|cloned voice|synthetic voice|voiceover|voice over)"
    )),
    sx_original = as.integer(str_detect(
      x,
      "(?i)(original (video|clip|post|upload|source)|source\\?|what'?s the source|older video|first posted)"
    )),
    sx_creator_denial = as.integer(str_detect(
      x,
      "(?i)(creator said|he said|she said|they said).{0,30}(not ai|no ai|real)"
    )),
    sx_detector = as.integer(str_detect(
      x,
      "(?i)(ai detector|detector says|detection tool|content credentials|c2pa|watermark)"
    )),
    sx_question = as.integer(str_detect(
      x,
      "(?i)(is this ai|is it ai|was this ai|ai\\?|generated\\?|real\\?|fake\\?)"
    ))
  )
}

make_balanced_weights <- function(y) {
  y <- as.integer(y)
  tab <- table(y)
  w <- 1 / as.numeric(tab[as.character(y)])
  w <- w / mean(w)
  as.numeric(w)
}

assign_group_folds <- function(dt, y_col, k = 5L) {
  g <- dt[
    !is.na(get(y_col)),
    {
      yy <- get(y_col)
      .(
        has_positive = as.integer(any(yy == 1L)),
        n_rows = .N
      )
    },
    by = group_id
  ]

  if (nrow(g) < k) {
    stop("Too few independent groups for ", k, " grouped folds.")
  }

  g[, tie_break := runif(.N)]
  setorder(g, has_positive, -n_rows, tie_break)

  g[, fold := {
    snake <- c(seq_len(k), rev(seq_len(k)))
    rep(snake, length.out = .N)
  }, by = has_positive]

  g[, .(group_id, fold)]
}

make_inner_foldid <- function(dt, y_col, k = 5L) {
  k_use <- min(k, uniqueN(dt$group_id))
  if (k_use < 3L) return(NULL)

  fm <- assign_group_folds(dt, y_col, k = k_use)
  out <- fm$fold[match(dt$group_id, fm$group_id)]
  if (anyNA(out)) stop("Inner grouped fold mapping failed.")
  as.integer(out)
}


align_sparse_columns <- function(mat, target_names) {
  # Align a sparse matrix to an exact training feature set without relying on
  # quanteda::dfm_match()/featnames(). Missing features are added as zero
  # columns and extra features are discarded.
  if (!inherits(mat, "Matrix")) {
    mat <- Matrix::Matrix(mat, sparse = TRUE)
  }

  current_names <- colnames(mat)
  if (is.null(current_names)) {
    stop("Sparse feature matrix has no column names.")
  }

  target_names <- as.character(target_names)
  map <- match(current_names, target_names)
  keep <- which(!is.na(map))

  if (!length(keep)) {
    out <- Matrix::sparseMatrix(
      i = integer(0),
      j = integer(0),
      dims = c(nrow(mat), length(target_names)),
      dimnames = list(rownames(mat), target_names)
    )
    return(methods::as(out, "dgCMatrix"))
  }

  sub <- mat[, keep, drop = FALSE]
  sm <- Matrix::summary(sub)

  # Matrix::summary() returns 1-based i/j coordinates for sparse matrices.
  new_j <- map[keep][sm$j]

  out <- Matrix::sparseMatrix(
    i = sm$i,
    j = new_j,
    x = sm$x,
    dims = c(nrow(mat), length(target_names)),
    dimnames = list(rownames(mat), target_names)
  )

  methods::as(out, "dgCMatrix")
}

build_hybrid_train <- function(text) {
  text <- normalize_text(text)

  # ---------------------------------------------------------------------------
  # WORD 1–2 GRAMS
  # ---------------------------------------------------------------------------
  wtok <- quanteda::tokens(
    text,
    remove_punct = TRUE,
    remove_symbols = FALSE,
    remove_numbers = FALSE,
    remove_url = FALSE,
    split_hyphens = TRUE
  )
  wtok <- quanteda::tokens_ngrams(wtok, n = 1:2)
  wdfm <- quanteda::dfm(wtok)

  if (!inherits(wdfm, "dfm")) {
    stop(
      "Word feature construction failed: expected a quanteda dfm, got ",
      paste(class(wdfm), collapse = "/")
    )
  }

  wdfm <- quanteda::dfm_trim(
    wdfm,
    min_docfreq = 2,
    docfreq_type = "count"
  )

  if (quanteda::nfeat(wdfm) > CFG$max_word_features) {
    tf <- quanteda::topfeatures(
      wdfm,
      n = CFG$max_word_features
    )
    keep_word <- names(tf)

    wdfm <- quanteda::dfm_select(
      wdfm,
      pattern = keep_word,
      selection = "keep",
      valuetype = "fixed"
    )
  }

  wdfm <- quanteda::dfm_weight(
    wdfm,
    scheme = "prop"
  )

  # Convert to Matrix BEFORE any renaming/alignment.
  wmat <- methods::as(wdfm, "dgCMatrix")
  word_features <- colnames(wmat)

  if (is.null(word_features) || !length(word_features)) {
    stop("No word features survived training preprocessing.")
  }

  colnames(wmat) <- paste0("W__", word_features)

  rm(wtok, wdfm)
  gc(FALSE)

  # ---------------------------------------------------------------------------
  # CHARACTER 3–5 GRAMS
  # ---------------------------------------------------------------------------
  ctok <- quanteda::tokens(
    text,
    what = "character",
    remove_punct = FALSE,
    remove_symbols = FALSE,
    remove_numbers = FALSE
  )
  ctok <- quanteda::tokens_ngrams(
    ctok,
    n = 3:5,
    concatenator = ""
  )
  cdfm <- quanteda::dfm(ctok)

  if (!inherits(cdfm, "dfm")) {
    stop(
      "Character feature construction failed: expected a quanteda dfm, got ",
      paste(class(cdfm), collapse = "/")
    )
  }

  cdfm <- quanteda::dfm_trim(
    cdfm,
    min_docfreq = 2,
    docfreq_type = "count"
  )

  if (quanteda::nfeat(cdfm) > CFG$max_char_features) {
    tfc <- quanteda::topfeatures(
      cdfm,
      n = CFG$max_char_features
    )
    keep_char <- names(tfc)

    cdfm <- quanteda::dfm_select(
      cdfm,
      pattern = keep_char,
      selection = "keep",
      valuetype = "fixed"
    )
  }

  cdfm <- quanteda::dfm_weight(
    cdfm,
    scheme = "prop"
  )

  cmat <- methods::as(cdfm, "dgCMatrix")
  char_features <- colnames(cmat)

  if (is.null(char_features) || !length(char_features)) {
    stop("No character features survived training preprocessing.")
  }

  colnames(cmat) <- paste0("C__", char_features)

  rm(ctok, cdfm)
  gc(FALSE)

  # ---------------------------------------------------------------------------
  # STRUCTURED FEATURES
  # ---------------------------------------------------------------------------
  sx <- structured_features(text)
  sx_mat <- Matrix::Matrix(
    as.matrix(sx),
    sparse = TRUE
  )
  sx_mat <- methods::as(sx_mat, "dgCMatrix")
  structured_raw_names <- names(sx)
  colnames(sx_mat) <- paste0(
    "S__",
    structured_raw_names
  )

  x <- cbind(
    wmat,
    cmat,
    sx_mat
  )
  x <- methods::as(x, "dgCMatrix")

  list(
    x = x,
    word_features = word_features,
    char_features = char_features,
    structured_raw_names = structured_raw_names,
    final_feature_names = colnames(x)
  )
}

build_hybrid_new <- function(text, feature_spec) {
  text <- normalize_text(text)

  # ---------------------------------------------------------------------------
  # WORD FEATURES
  # ---------------------------------------------------------------------------
  wtok <- quanteda::tokens(
    text,
    remove_punct = TRUE,
    remove_symbols = FALSE,
    remove_numbers = FALSE,
    remove_url = FALSE,
    split_hyphens = TRUE
  )
  wtok <- quanteda::tokens_ngrams(wtok, n = 1:2)
  wdfm <- quanteda::dfm(wtok)

  if (!inherits(wdfm, "dfm")) {
    stop(
      "New-data word construction failed: expected dfm, got ",
      paste(class(wdfm), collapse = "/")
    )
  }

  wdfm <- quanteda::dfm_weight(
    wdfm,
    scheme = "prop"
  )
  wmat_raw <- methods::as(wdfm, "dgCMatrix")

  wmat <- align_sparse_columns(
    wmat_raw,
    feature_spec$word_features
  )
  colnames(wmat) <- paste0(
    "W__",
    feature_spec$word_features
  )

  rm(wtok, wdfm, wmat_raw)
  gc(FALSE)

  # ---------------------------------------------------------------------------
  # CHARACTER FEATURES
  # ---------------------------------------------------------------------------
  ctok <- quanteda::tokens(
    text,
    what = "character",
    remove_punct = FALSE,
    remove_symbols = FALSE,
    remove_numbers = FALSE
  )
  ctok <- quanteda::tokens_ngrams(
    ctok,
    n = 3:5,
    concatenator = ""
  )
  cdfm <- quanteda::dfm(ctok)

  if (!inherits(cdfm, "dfm")) {
    stop(
      "New-data character construction failed: expected dfm, got ",
      paste(class(cdfm), collapse = "/")
    )
  }

  cdfm <- quanteda::dfm_weight(
    cdfm,
    scheme = "prop"
  )
  cmat_raw <- methods::as(cdfm, "dgCMatrix")

  cmat <- align_sparse_columns(
    cmat_raw,
    feature_spec$char_features
  )
  colnames(cmat) <- paste0(
    "C__",
    feature_spec$char_features
  )

  rm(ctok, cdfm, cmat_raw)
  gc(FALSE)

  # ---------------------------------------------------------------------------
  # STRUCTURED FEATURES
  # ---------------------------------------------------------------------------
  sx <- structured_features(text)

  # Recreate exactly the training structured-feature set and order.
  for (nm in setdiff(
    feature_spec$structured_raw_names,
    names(sx)
  )) {
    sx[, (nm) := 0L]
  }

  structured_cols <- feature_spec$structured_raw_names
  sx <- sx[
    ,
    ..structured_cols
  ]

  sx_mat <- Matrix::Matrix(
    as.matrix(sx),
    sparse = TRUE
  )
  sx_mat <- methods::as(sx_mat, "dgCMatrix")
  colnames(sx_mat) <- paste0(
    "S__",
    feature_spec$structured_raw_names
  )

  x <- cbind(
    wmat,
    cmat,
    sx_mat
  )
  x <- methods::as(x, "dgCMatrix")

  # Hard compatibility check: train/test columns must be identical.
  if (!identical(
    colnames(x),
    feature_spec$final_feature_names
  )) {
    stop(
      "Train/test feature alignment failed. ",
      "This is a V3.5.3 internal consistency check."
    )
  }

  x
}

binary_metrics <- function(y, prob, threshold) {
  keep <- !is.na(y) & !is.na(prob)
  y <- as.integer(y[keep])
  prob <- as.numeric(prob[keep])
  pred <- as.integer(prob >= threshold)

  tp <- sum(pred == 1L & y == 1L)
  fp <- sum(pred == 1L & y == 0L)
  fn <- sum(pred == 0L & y == 1L)
  tn <- sum(pred == 0L & y == 0L)

  precision <- ifelse(tp + fp == 0, NA_real_, tp / (tp + fp))
  recall <- ifelse(tp + fn == 0, NA_real_, tp / (tp + fn))
  specificity <- ifelse(tn + fp == 0, NA_real_, tn / (tn + fp))
  accuracy <- (tp + tn) / (tp + fp + fn + tn)
  f1 <- ifelse(
    is.na(precision) | is.na(recall) | precision + recall == 0,
    NA_real_,
    2 * precision * recall / (precision + recall)
  )
  beta2 <- 4
  f2 <- ifelse(
    is.na(precision) | is.na(recall) |
      beta2 * precision + recall == 0,
    NA_real_,
    (1 + beta2) * precision * recall /
      (beta2 * precision + recall)
  )

  data.table(
    threshold = threshold,
    tp = tp,
    fp = fp,
    fn = fn,
    tn = tn,
    precision = precision,
    recall = recall,
    specificity = specificity,
    accuracy = accuracy,
    f1 = f1,
    f2 = f2
  )
}

choose_retrieval_threshold <- function(y, prob) {
  grid <- seq(0.01, 0.99, by = 0.01)

  tab <- rbindlist(lapply(grid, function(th) {
    binary_metrics(y, prob, th)
  }))

  feasible <- tab[
    recall >= CFG$target_recall &
      precision >= CFG$min_precision_for_retrieval
  ]

  if (nrow(feasible)) {
    # Among thresholds meeting target recall, maximize precision first,
    # then F2 and threshold.
    setorder(feasible, -precision, -f2, -threshold)
    best <- feasible[1]
    gate <- TRUE
  } else {
    # Diagnostic fallback only; do not proceed to full retrieval.
    setorder(tab, -f2, -recall, -precision)
    best <- tab[1]
    gate <- FALSE
  }

  list(
    best = best,
    grid = tab,
    gate = gate
  )
}

# ==============================================================================
# 5. GROUPED OOF AI-SPECIFIC RETRIEVAL MODEL
# ==============================================================================

prediction_cache <- file.path(
  CFG$output_dir,
  "15_AI_retrieval_scores_v3_5.csv"
)

model_metrics_cache <- file.path(
  CFG$output_dir,
  "05_AI_retrieval_OOF_summary.csv"
)

retrieval_threshold_cache <- file.path(
  CFG$output_dir,
  "07_AI_retrieval_threshold.txt"
)

need_fit <- !(
  isTRUE(CFG$reuse_prediction_cache) &&
    file.exists(prediction_cache) &&
    file.exists(model_metrics_cache) &&
    file.exists(retrieval_threshold_cache)
)

if (need_fit) {
  fold_map <- assign_group_folds(
    gold_ml,
    y_col = "AI_provenance_gold",
    k = CFG$folds
  )

  gold_cv <- merge(
    gold_ml,
    fold_map,
    by = "group_id",
    all.x = TRUE
  )

  oof <- rep(NA_real_, nrow(gold_cv))

  for (f in sort(unique(gold_cv$fold))) {
    tr <- which(gold_cv$fold != f)
    te <- which(gold_cv$fold == f)

    tr_dt <- gold_cv[tr]
    te_dt <- gold_cv[te]

    spec <- build_hybrid_train(tr_dt$ml_text)
    xte <- build_hybrid_new(te_dt$ml_text, spec)

    ytr <- tr_dt$AI_provenance_gold
    train_w <- make_balanced_weights(ytr)

    inner_foldid <- make_inner_foldid(
      tr_dt,
      y_col = "AI_provenance_gold",
      k = CFG$folds
    )

    fit <- glmnet::cv.glmnet(
      x = spec$x,
      y = ytr,
      family = "binomial",
      alpha = CFG$alpha,
      weights = train_w,
      foldid = inner_foldid,
      type.measure = "deviance",
      standardize = FALSE
    )

    oof[te] <- as.numeric(
      predict(
        fit,
        newx = xte,
        s = "lambda.min",
        type = "response"
      )
    )

    message("[4/10] OOF fold ", f, "/", CFG$folds, " completed.")

    rm(tr_dt, te_dt, spec, xte, fit)
    gc()
  }

  gold_cv[, oof_AI_prob := oof]

  threshold_info <- choose_retrieval_threshold(
    gold_cv$AI_provenance_gold,
    gold_cv$oof_AI_prob
  )

  threshold <- as.numeric(threshold_info$best$threshold)

  overall_metrics <- binary_metrics(
    gold_cv$AI_provenance_gold,
    gold_cv$oof_AI_prob,
    threshold
  )
  overall_metrics[, scope := "overall"]

  stratum_metrics <- rbindlist(lapply(
    unique(gold_cv$validation_stratum),
    function(s) {
      d <- gold_cv[validation_stratum == s]
      z <- binary_metrics(
        d$AI_provenance_gold,
        d$oof_AI_prob,
        threshold
      )
      z[, scope := paste0("stratum::", s)]
      z
    }
  ), fill = TRUE)

  oof_summary <- rbindlist(
    list(overall_metrics, stratum_metrics),
    fill = TRUE
  )

  fwrite(
    oof_summary,
    file.path(CFG$output_dir, "05_AI_retrieval_OOF_summary.csv"),
    bom = TRUE
  )
  fwrite(
    threshold_info$grid,
    file.path(CFG$output_dir, "06_AI_retrieval_threshold_grid.csv"),
    bom = TRUE
  )
  writeLines(
    as.character(threshold),
    retrieval_threshold_cache
  )

  # Save OOF gold predictions for error analysis.
  fwrite(
    gold_cv[, .(
      comment_key,
      validation_stratum,
      AI_provenance_gold,
      oof_AI_prob,
      fold,
      comment_text = comment_text_ml,
      technology_final,
      stance_final
    )],
    file.path(CFG$output_dir, "08_AI_retrieval_gold_OOF_predictions.csv"),
    bom = TRUE
  )

  if (!isTRUE(threshold_info$gate)) {
    stop(
      "\nV3.5 stopped before full-corpus retrieval.\n",
      "No OOF threshold simultaneously achieved recall >= ",
      CFG$target_recall,
      " and precision >= ",
      CFG$min_precision_for_retrieval,
      ".\nInspect 05_AI_retrieval_OOF_summary.csv and ",
      "06_AI_retrieval_threshold_grid.csv."
    )
  }

  message(
    "[5/10] Retrieval gate passed. Threshold = ",
    sprintf("%.2f", threshold),
    " | recall = ",
    sprintf("%.3f", overall_metrics$recall),
    " | precision = ",
    sprintf("%.3f", overall_metrics$precision)
  )

  # ---------------------------------------------------------------------------
  # Fit final retrieval model on all gold.
  # ---------------------------------------------------------------------------
  full_spec <- build_hybrid_train(gold_ml$ml_text)
  yall <- gold_ml$AI_provenance_gold
  wall <- make_balanced_weights(yall)
  inner_all <- make_inner_foldid(
    gold_ml,
    y_col = "AI_provenance_gold",
    k = CFG$folds
  )

  final_fit <- glmnet::cv.glmnet(
    x = full_spec$x,
    y = yall,
    family = "binomial",
    alpha = CFG$alpha,
    weights = wall,
    foldid = inner_all,
    type.measure = "deviance",
    standardize = FALSE
  )

  # ---------------------------------------------------------------------------
  # Full-corpus prediction in chunks.
  # ---------------------------------------------------------------------------
  comments_main[, AI_retrieval_prob := NA_real_]

  starts <- seq.int(
    1L,
    nrow(comments_main),
    by = CFG$prediction_chunk
  )

  for (st in starts) {
    en <- min(
      nrow(comments_main),
      st + CFG$prediction_chunk - 1L
    )
    ii <- st:en

    xnew <- build_hybrid_new(
      comments_main$text[ii],
      full_spec
    )

    comments_main$AI_retrieval_prob[ii] <- as.numeric(
      predict(
        final_fit,
        newx = xnew,
        s = "lambda.min",
        type = "response"
      )
    )

    message(
      "[6/10] Full retrieval prediction: ",
      format(en, big.mark = ","),
      " / ",
      format(nrow(comments_main), big.mark = ",")
    )

    rm(xnew)
    gc()
  }

  # High-recall explicit lexical union. This is only a retrieval aid.
  comments_main[, AI_rule_retrieval := stringr::str_detect(
    normalize_text(text),
    direct_ai_regex
  )]

  comments_main[, AI_model_retrieval := (
    AI_retrieval_prob >= threshold
  )]

  comments_main[, AI_candidate_retrieval := (
    AI_model_retrieval | AI_rule_retrieval
  )]

  fwrite(
    comments_main[, .(
      comment_key,
      source_row,
      AI_retrieval_prob,
      AI_model_retrieval,
      AI_rule_retrieval,
      AI_candidate_retrieval
    )],
    prediction_cache
  )

  rm(full_spec, final_fit)
  gc()

} else {
  threshold <- as.numeric(
    readLines(retrieval_threshold_cache, warn = FALSE)[1]
  )

  pred <- fread(prediction_cache)
  pred[, comment_key := as.character(comment_key)]

  comments_main <- merge(
    comments_main,
    pred,
    by = c("comment_key", "source_row"),
    all.x = TRUE,
    sort = FALSE
  )

  message(
    "[4-6/10] Reused V3.5 retrieval prediction cache. Threshold = ",
    threshold
  )
}


# ==============================================================================
# 5A. COMBINED MODEL + RULE OOF AUDIT
# ==============================================================================

# Deployment uses MODEL OR RULE, so evaluation must report the same union.
oof_pred_path <- file.path(
  CFG$output_dir,
  "08_AI_retrieval_gold_OOF_predictions.csv"
)

if (!file.exists(oof_pred_path)) {
  stop(
    "Missing 08_AI_retrieval_gold_OOF_predictions.csv. ",
    "Run the OOF stage once before the combined audit."
  )
}

oof_eval <- fread(oof_pred_path, encoding = "UTF-8")
oof_eval[, comment_key := as.character(comment_key)]

oof_eval[, AI_rule_OOF := stringr::str_detect(
  normalize_text(comment_text),
  direct_ai_regex
)]
oof_eval[, AI_model_OOF := oof_AI_prob >= threshold]
oof_eval[, AI_combined_OOF := AI_model_OOF | AI_rule_OOF]

combined_metrics_from_pred <- function(d, scope_label) {
  y <- as.integer(d$AI_provenance_gold)
  pred <- as.integer(d$AI_combined_OOF)

  tp <- sum(pred == 1L & y == 1L, na.rm = TRUE)
  fp <- sum(pred == 1L & y == 0L, na.rm = TRUE)
  fn <- sum(pred == 0L & y == 1L, na.rm = TRUE)
  tn <- sum(pred == 0L & y == 0L, na.rm = TRUE)

  precision <- ifelse(tp + fp == 0, NA_real_, tp / (tp + fp))
  recall <- ifelse(tp + fn == 0, NA_real_, tp / (tp + fn))
  specificity <- ifelse(tn + fp == 0, NA_real_, tn / (tn + fp))
  accuracy <- (tp + tn) / (tp + fp + fn + tn)
  f1 <- ifelse(
    is.na(precision) | is.na(recall) | precision + recall == 0,
    NA_real_,
    2 * precision * recall / (precision + recall)
  )

  data.table(
    scope = scope_label,
    threshold = threshold,
    tp = tp,
    fp = fp,
    fn = fn,
    tn = tn,
    precision = precision,
    recall = recall,
    specificity = specificity,
    accuracy = accuracy,
    f1 = f1
  )
}

combined_oof_summary <- rbindlist(
  c(
    list(
      combined_metrics_from_pred(
        oof_eval,
        "overall"
      )
    ),
    lapply(
      unique(oof_eval$validation_stratum),
      function(s) {
        combined_metrics_from_pred(
          oof_eval[validation_stratum == s],
          paste0("stratum::", s)
        )
      }
    )
  ),
  fill = TRUE
)

fwrite(
  combined_oof_summary,
  file.path(
    CFG$output_dir,
    "05A_AI_combined_model_rule_OOF_summary.csv"
  ),
  bom = TRUE
)

combined_overall_recall <- combined_oof_summary[
  scope == "overall",
  recall
]

if (
  is.na(combined_overall_recall) ||
    combined_overall_recall < CFG$target_recall
) {
  stop(
    "\nCombined MODEL OR RULE OOF recall = ",
    sprintf("%.3f", combined_overall_recall),
    ", below target ",
    CFG$target_recall,
    ".\nDo not start human candidate review yet."
  )
}

message(
  "[5A/10] Combined MODEL OR RULE OOF recall = ",
  sprintf("%.3f", combined_overall_recall),
  " | precision = ",
  sprintf(
    "%.3f",
    combined_oof_summary[scope == "overall", precision]
  )
)

# ==============================================================================
# 6. OVERLAY EXISTING GOLD + GENERATE HUMAN REVIEW FILES
# ==============================================================================

gold_overlay <- gold[, .(
  comment_key,
  human_gold = TRUE,
  gold_AI = AI_provenance_gold,
  gold_technology = technology_final,
  gold_stance = stance_final,
  gold_reason = primary_reason_final,
  gold_reason_type = reason_type_final
)]

comments_main <- merge(
  comments_main,
  gold_overlay,
  by = "comment_key",
  all.x = TRUE,
  sort = FALSE
)

comments_main[is.na(human_gold), human_gold := FALSE]

new_candidate <- comments_main[
  human_gold == FALSE &
    AI_candidate_retrieval %in% TRUE
]

candidate_count <- nrow(new_candidate)

candidate_audit <- data.table(
  main_language_comments = nrow(comments_main),
  existing_gold_rows = sum(comments_main$human_gold),
  existing_gold_AI = sum(
    comments_main$gold_AI == 1L,
    na.rm = TRUE
  ),
  new_AI_candidates = candidate_count,
  threshold = threshold,
  model_only_candidates = sum(
    new_candidate$AI_model_retrieval &
      !new_candidate$AI_rule_retrieval,
    na.rm = TRUE
  ),
  rule_only_candidates = sum(
    !new_candidate$AI_model_retrieval &
      new_candidate$AI_rule_retrieval,
    na.rm = TRUE
  ),
  both_candidates = sum(
    new_candidate$AI_model_retrieval &
      new_candidate$AI_rule_retrieval,
    na.rm = TRUE
  )
)

fwrite(
  candidate_audit,
  file.path(CFG$output_dir, "09_AI_candidate_retrieval_audit.csv"),
  bom = TRUE
)

if (candidate_count > CFG$max_new_candidates_for_full_review) {
  # Save score distribution for redesign before asking for infeasible manual work.
  quant <- comments_main[
    human_gold == FALSE,
    .(
      q001 = quantile(AI_retrieval_prob, .001, na.rm = TRUE),
      q01 = quantile(AI_retrieval_prob, .01, na.rm = TRUE),
      q05 = quantile(AI_retrieval_prob, .05, na.rm = TRUE),
      q10 = quantile(AI_retrieval_prob, .10, na.rm = TRUE),
      q25 = quantile(AI_retrieval_prob, .25, na.rm = TRUE),
      q50 = quantile(AI_retrieval_prob, .50, na.rm = TRUE),
      q75 = quantile(AI_retrieval_prob, .75, na.rm = TRUE),
      q90 = quantile(AI_retrieval_prob, .90, na.rm = TRUE),
      q95 = quantile(AI_retrieval_prob, .95, na.rm = TRUE),
      q99 = quantile(AI_retrieval_prob, .99, na.rm = TRUE)
    )
  ]

  fwrite(
    quant,
    file.path(CFG$output_dir, "10_AI_score_distribution.csv"),
    bom = TRUE
  )

  stop(
    "\nV3.5 retrieved ", format(candidate_count, big.mark = ","),
    " new AI candidates, exceeding the pre-set full-review ceiling of ",
    format(CFG$max_new_candidates_for_full_review, big.mark = ","),
    ".\nNo inferential analysis was run.\n",
    "Inspect 09_AI_candidate_retrieval_audit.csv and ",
    "10_AI_score_distribution.csv before changing the retrieval design."
  )
}

# Human review files.
candidate_review_path <- file.path(
  CFG$output_dir,
  "AI_CANDIDATE_REVIEW_TEMPLATE.csv"
)
candidate_completed_candidates <- unique(c(
  file.path(CFG$output_dir, "AI_CANDIDATE_REVIEW_COMPLETED.csv"),
  file.path(getwd(), "AI_CANDIDATE_REVIEW_COMPLETED.csv"),
  list.files(
    CFG$output_dir,
    pattern = "^AI_CANDIDATE_REVIEW_COMPLETED(\\([0-9]+\\))?\\.csv$",
    full.names = TRUE
  ),
  list.files(
    getwd(),
    pattern = "^AI_CANDIDATE_REVIEW_COMPLETED(\\([0-9]+\\))?\\.csv$",
    full.names = TRUE
  )
))
candidate_completed_candidates <- candidate_completed_candidates[
  file.exists(candidate_completed_candidates)
]
if (length(candidate_completed_candidates) > 1L) {
  candidate_completed_candidates <- candidate_completed_candidates[
    order(file.info(candidate_completed_candidates)$mtime, decreasing = TRUE)
  ]
}

negative_audit_path <- file.path(
  CFG$output_dir,
  "AI_NEGATIVE_AUDIT_TEMPLATE.csv"
)
negative_completed_candidates <- unique(c(
  file.path(CFG$output_dir, "AI_NEGATIVE_AUDIT_COMPLETED.csv"),
  file.path(getwd(), "AI_NEGATIVE_AUDIT_COMPLETED.csv"),
  list.files(
    CFG$output_dir,
    pattern = "^AI_NEGATIVE_AUDIT_COMPLETED(\\([0-9]+\\))?\\.csv$",
    full.names = TRUE
  ),
  list.files(
    getwd(),
    pattern = "^AI_NEGATIVE_AUDIT_COMPLETED(\\([0-9]+\\))?\\.csv$",
    full.names = TRUE
  )
))
negative_completed_candidates <- negative_completed_candidates[
  file.exists(negative_completed_candidates)
]
if (length(negative_completed_candidates) > 1L) {
  negative_completed_candidates <- negative_completed_candidates[
    order(file.info(negative_completed_candidates)$mtime, decreasing = TRUE)
  ]
}

if (!length(candidate_completed_candidates)) {
  candidate_review <- new_candidate[, .(
    comment_key,
    source_row,
    video_id,
    comment_text = text,
    video_description = description,
    AI_retrieval_prob,
    AI_model_retrieval,
    AI_rule_retrieval,
    retrieval_source = fcase(
      AI_model_retrieval & AI_rule_retrieval, "model+rule",
      AI_model_retrieval, "model_only",
      AI_rule_retrieval, "rule_only",
      default = "unknown"
    ),

    # Human review fields:
    AI_provenance_final = NA_integer_,   # 1/0/9
    stance_final = NA_character_,        # A/S/U/C/M/X/OTHER
    primary_reason_final = NA_integer_,  # 1/0
    reason_type_final = NA_character_,
    coder_confidence = NA_character_,
    coder_notes = NA_character_
  )]

  setorder(
    candidate_review,
    -AI_retrieval_prob
  )

  fwrite(
    candidate_review,
    candidate_review_path,
    bom = TRUE
  )
}

# Predicted-negative audit using mutually exclusive lexical-risk strata.
if (!length(negative_completed_candidates)) {
  neg_pool <- comments_main[
    human_gold == FALSE &
      AI_candidate_retrieval == FALSE &
      !is.na(AI_retrieval_prob)
  ]

  neg_pool[, audit_soft_ai_signal := stringr::str_detect(
    normalize_text(text),
    soft_ai_risk_regex
  )]

  neg_pool[, audit_production_signal := stringr::str_detect(
    normalize_text(text),
    production_provenance_regex
  )]

  # Mutually exclusive strata. Every predicted negative belongs to exactly one.
  neg_pool[, audit_stratum := fcase(
    audit_soft_ai_signal,
    "soft_AI_semantic_risk",
    !audit_soft_ai_signal & audit_production_signal,
    "production_provenance_risk",
    default = "baseline_random"
  )]

  audit_population_table <- neg_pool[
    , .(
      population_N = .N,
      prob_min = min(AI_retrieval_prob, na.rm = TRUE),
      prob_median = median(AI_retrieval_prob, na.rm = TRUE),
      prob_max = max(AI_retrieval_prob, na.rm = TRUE)
    ),
    by = audit_stratum
  ]

  fwrite(
    audit_population_table,
    file.path(
      CFG$output_dir,
      "11_NEGATIVE_AUDIT_STRATUM_POPULATIONS.csv"
    ),
    bom = TRUE
  )

  audit_sample_stratum <- function(d, n_take, label) {
    dd <- d[audit_stratum == label]
    Npop <- nrow(dd)

    if (!Npop) return(data.table())

    ns <- min(n_take, Npop)

    # Simple random sampling within each fixed stratum.
    z <- dd[sample.int(Npop, ns, replace = FALSE)]

    z[, `:=`(
      audit_population_N = Npop,
      audit_sample_N = ns,
      audit_inclusion_probability = ns / Npop,
      audit_weight = Npop / ns
    )]

    z
  }

  set.seed(CFG$seed + 3504L)

  neg_audit <- rbindlist(
    list(
      audit_sample_stratum(
        neg_pool,
        CFG$negative_audit_soft_ai_n,
        "soft_AI_semantic_risk"
      ),
      audit_sample_stratum(
        neg_pool,
        CFG$negative_audit_production_n,
        "production_provenance_risk"
      ),
      audit_sample_stratum(
        neg_pool,
        CFG$negative_audit_baseline_n,
        "baseline_random"
      )
    ),
    fill = TRUE
  )

  neg_audit_template <- neg_audit[, .(
    comment_key,
    source_row,
    video_id,
    comment_text = text,
    video_description = description,
    AI_retrieval_prob,
    audit_stratum,
    audit_population_N,
    audit_sample_N,
    audit_inclusion_probability,
    audit_weight,

    # Human review:
    AI_provenance_final = NA_integer_,   # 1/0/9
    stance_final = NA_character_,
    primary_reason_final = NA_integer_,
    reason_type_final = NA_character_,
    coder_confidence = NA_character_,
    coder_notes = NA_character_
  )]

  setorder(
    neg_audit_template,
    audit_stratum,
    -AI_retrieval_prob
  )

  fwrite(
    neg_audit_template,
    negative_audit_path,
    bom = TRUE
  )
}

if (
  !length(candidate_completed_candidates) ||
    !length(negative_completed_candidates)
) {
  message("============================================================")
  message("V3.5.5 RETRIEVAL STAGE COMPLETED.")
  message("Machine predictions are NOT final labels.")
  message("Complete BOTH human-review files:")
  message("  ", candidate_review_path)
  message("  ", negative_audit_path)
  message("")
  message("Save completed copies as:")
  message("  AI_CANDIDATE_REVIEW_COMPLETED.csv")
  message("  AI_NEGATIVE_AUDIT_COMPLETED.csv")
  message("")
  message("Then rerun this same V3.5.5 script.")
  message("============================================================")
  stop(
    "V3.5.5 manual-review checkpoint reached. ",
    "This is an intentional stop; the R session should remain open.",
    call. = FALSE
  )
}

# ==============================================================================
# 7. INGEST COMPLETED HUMAN REVIEW + NEGATIVE AUDIT
# ==============================================================================

cand_done <- fread(
  candidate_completed_candidates[1],
  encoding = "UTF-8"
)
neg_done <- fread(
  negative_completed_candidates[1],
  encoding = "UTF-8"
)

cand_done[, comment_key := as.character(comment_key)]
neg_done[, comment_key := as.character(comment_key)]

required_review <- c(
  "comment_key",
  "AI_provenance_final",
  "stance_final",
  "primary_reason_final",
  "reason_type_final"
)

for (nm in required_review) {
  if (!nm %in% names(cand_done)) {
    stop("Candidate review is missing column: ", nm)
  }
  if (!nm %in% names(neg_done)) {
    stop("Negative audit is missing column: ", nm)
  }
}

cand_done[, AI_provenance_final := as.integer(AI_provenance_final)]
neg_done[, AI_provenance_final := as.integer(AI_provenance_final)]

if (any(!cand_done$AI_provenance_final %in% c(0L, 1L, 9L))) {
  stop("Candidate review contains invalid AI_provenance_final values.")
}
if (any(!neg_done$AI_provenance_final %in% c(0L, 1L, 9L))) {
  stop("Negative audit contains invalid AI_provenance_final values.")
}

# Candidate review should cover every retrieved new candidate.
if (nrow(cand_done) != candidate_count) {
  stop(
    "Completed candidate review rows (", nrow(cand_done),
    ") do not match retrieved new candidates (", candidate_count, ")."
  )
}

# Estimate residual missed AI comments in predicted-negative pool.
neg_done_valid <- neg_done[
  AI_provenance_final %in% c(0L, 1L)
]

neg_audit_summary <- neg_done_valid[
  , .(
    sample_n = .N,
    positives = sum(AI_provenance_final == 1L),
    population_N = unique(audit_population_N)[1],
    audit_weight = unique(audit_weight)[1],
    # The sampled positives are already manually recovered into the confirmed
    # AI corpus. Estimate only positives remaining among UNREVIEWED negatives.
    estimated_remaining_missed_AI = sum(
      AI_provenance_final == 1L
    ) * pmax(unique(audit_weight)[1] - 1, 0)
  ),
  by = audit_stratum
]

estimated_missed_AI <- sum(
  neg_audit_summary$estimated_remaining_missed_AI,
  na.rm = TRUE
)

new_confirmed_AI <- sum(
  cand_done$AI_provenance_final == 1L,
  na.rm = TRUE
)

existing_gold_AI <- sum(
  gold_ml$AI_provenance_gold == 1L,
  na.rm = TRUE
)

audit_confirmed_AI <- sum(
  neg_done$AI_provenance_final == 1L,
  na.rm = TRUE
)

confirmed_AI_total <- (
  existing_gold_AI +
    new_confirmed_AI +
    audit_confirmed_AI
)

estimated_final_recall <- confirmed_AI_total / (
  confirmed_AI_total + estimated_missed_AI
)

retrieval_final_audit <- data.table(
  existing_gold_AI = existing_gold_AI,
  new_candidate_confirmed_AI = new_confirmed_AI,
  negative_audit_confirmed_AI = audit_confirmed_AI,
  confirmed_AI_total = confirmed_AI_total,
  estimated_missed_AI_in_unreviewed_negatives = estimated_missed_AI,
  estimated_final_retrieval_recall = estimated_final_recall,
  minimum_required_recall = CFG$min_estimated_final_recall
)

fwrite(
  neg_audit_summary,
  file.path(CFG$output_dir, "16_negative_audit_by_score_stratum.csv"),
  bom = TRUE
)
fwrite(
  retrieval_final_audit,
  file.path(CFG$output_dir, "17_FINAL_RETRIEVAL_AUDIT.csv"),
  bom = TRUE
)

if (
  is.na(estimated_final_recall) ||
    estimated_final_recall < CFG$min_estimated_final_recall
) {
  stop(
    "\nV3.5 human negative-audit gate failed.\n",
    "Estimated final AI retrieval recall = ",
    sprintf("%.3f", estimated_final_recall),
    ", below required ",
    CFG$min_estimated_final_recall,
    ".\nDo NOT proceed to final inferential analyses. ",
    "Use the missed AI comments to expand retrieval again."
  )
}

message(
  "[7/10] Human retrieval audit passed. Estimated recall = ",
  sprintf("%.3f", estimated_final_recall)
)

# ==============================================================================
# 8. BUILD FINAL HUMAN-CONFIRMED AI CORPUS
# ==============================================================================

# Existing gold AI positives.
gold_pos <- gold_ml[
  AI_provenance_gold == 1L,
  .(
    comment_key,
    AI_provenance_final = 1L,
    stance_final = stance_final,
    primary_reason_final = primary_reason_final,
    reason_type_final = reason_type_final,
    label_source = "original_human_gold"
  )
]

# New candidate positives.
cand_pos <- cand_done[
  AI_provenance_final == 1L,
  .(
    comment_key,
    AI_provenance_final,
    stance_final = as.character(stance_final),
    primary_reason_final = as.integer(primary_reason_final),
    reason_type_final = as.character(reason_type_final),
    label_source = "retrieved_candidate_human_review"
  )
]

# Negative audit positives.
neg_pos <- neg_done[
  AI_provenance_final == 1L,
  .(
    comment_key,
    AI_provenance_final,
    stance_final = as.character(stance_final),
    primary_reason_final = as.integer(primary_reason_final),
    reason_type_final = as.character(reason_type_final),
    label_source = "predicted_negative_audit_positive"
  )
]

final_ai_labels <- rbindlist(
  list(gold_pos, cand_pos, neg_pos),
  use.names = TRUE,
  fill = TRUE
)

final_ai_labels <- final_ai_labels[!duplicated(comment_key)]

fwrite(
  final_ai_labels,
  file.path(CFG$output_dir, "18_FINAL_HUMAN_CONFIRMED_AI_LABELS.csv"),
  bom = TRUE
)

# Attach final AI labels to entire main corpus.
comments_main[, final_AI_provenance := FALSE]
comments_main[, final_stance := NA_character_]
comments_main[, final_reason := NA_integer_]
comments_main[, final_reason_type := NA_character_]

comments_main[
  final_ai_labels,
  on = "comment_key",
  `:=`(
    final_AI_provenance = TRUE,
    final_stance = i.stance_final,
    final_reason = i.primary_reason_final,
    final_reason_type = i.reason_type_final
  )
]

comments_main[, final_AI_challenge := (
  final_AI_provenance &
    final_stance %in% c("A", "S")
)]

comments_main[, final_counter_authentication := (
  final_AI_provenance &
    final_stance == "C"
)]

comments_main[, final_discourse_type := fcase(
  final_AI_provenance & final_stance == "A", "AI_assertion",
  final_AI_provenance & final_stance == "S", "AI_suspicion",
  final_AI_provenance & final_stance == "C", "counter_authentication",
  final_AI_provenance, "other_AI_provenance",
  default = "other"
)]

# ==============================================================================
# 9. DESCRIPTIVES + H1 EVIDENTIARY ASYMMETRY
# ==============================================================================

final_summary <- comments_main[, .(
  n_comments = .N,
  n_AI_provenance = sum(final_AI_provenance),
  n_AI_assertion = sum(final_stance == "A", na.rm = TRUE),
  n_AI_suspicion = sum(final_stance == "S", na.rm = TRUE),
  n_counter_authentication = sum(final_stance == "C", na.rm = TRUE),
  n_AI_challenge = sum(final_AI_challenge),
  n_videos_AI_provenance = uniqueN(
    source_row[final_AI_provenance]
  ),
  n_videos_AI_challenge = uniqueN(
    source_row[final_AI_challenge]
  )
)]

fwrite(
  final_summary,
  file.path(CFG$output_dir, "20_FINAL_AI_LABEL_SUMMARY.csv"),
  bom = TRUE
)

category_summary <- comments_main[
  , .(
    comments = .N,
    videos = uniqueN(source_row),
    median_likes = as.numeric(
      median(like_count, na.rm = TRUE)
    ),
    median_replies = as.numeric(
      median(reply_count, na.rm = TRUE)
    )
  ),
  by = final_discourse_type
][order(-comments)]

fwrite(
  category_summary,
  file.path(CFG$output_dir, "21_FINAL_CATEGORY_SUMMARY.csv"),
  bom = TRUE
)

# H1: A vs C explicit reason provision.
h1 <- comments_main[
  final_AI_provenance &
    final_stance %in% c("A", "C") &
    final_reason %in% c(0L, 1L)
]

h1_desc <- h1[, .(
  n = .N,
  reason_n = sum(final_reason == 1L),
  reason_rate = mean(final_reason == 1L)
), by = final_stance]

fwrite(
  h1_desc,
  file.path(CFG$output_dir, "22_FINAL_REASON_ASYMMETRY_DESCRIPTIVES.csv"),
  bom = TRUE
)

h1[, counter_flag := as.integer(final_stance == "C")]

overlap_videos <- h1[
  , .(
    has_A = any(final_stance == "A"),
    has_C = any(final_stance == "C")
  ),
  by = source_row
][has_A & has_C, source_row]

if (length(overlap_videos) >= 10L) {
  h1_fe <- h1[source_row %in% overlap_videos]

  h1_model <- fixest::feols(
    final_reason ~ counter_flag | source_row,
    data = h1_fe,
    cluster = ~source_row
  )

  fwrite(
    data.table::as.data.table(
      broom::tidy(
        h1_model,
        conf.int = TRUE
      )
    ),
    file.path(CFG$output_dir, "23_FINAL_REASON_ASYMMETRY_FE.csv"),
    bom = TRUE
  )

  capture.output(
    summary(h1_model),
    file = file.path(
      CFG$output_dir,
      "23_FINAL_REASON_ASYMMETRY_FE.txt"
    )
  )
} else {
  writeLines(
    paste0(
      "Not run: only ",
      length(overlap_videos),
      " videos contain both A and C."
    ),
    file.path(
      CFG$output_dir,
      "23_FINAL_REASON_ASYMMETRY_FE.txt"
    )
  )
}

reason_type_summary <- comments_main[
  final_AI_provenance &
    final_stance %in% c("A", "S", "C") &
    final_reason == 1L,
  .N,
  by = .(final_stance, final_reason_type)
][order(final_stance, -N)]

fwrite(
  reason_type_summary,
  file.path(CFG$output_dir, "24_FINAL_REASON_TYPE_BY_STANCE.csv"),
  bom = TRUE
)

# ==============================================================================
# 10. CONDITIONAL PERMUTATION A / B
# ==============================================================================

choose2 <- function(x) {
  x * pmax(x - 1, 0) / 2
}

# A: local concentration of A+S challenges.
permA <- comments_main[
  !is.na(comment_time_utc)
]

permA[, year_num := lubridate::year(comment_time_utc)]
permA[, half := ifelse(
  lubridate::month(comment_time_utc) <= 6,
  "H1",
  "H2"
)]
permA[, time_stratum := paste0(year_num, "_", half)]

qv <- unique(quantile(
  permA$n_retrieved_comments,
  probs = seq(0, 1, .25),
  na.rm = TRUE,
  type = 2
))

if (length(qv) >= 3L) {
  permA[, volume_stratum := cut(
    n_retrieved_comments,
    breaks = qv,
    include.lowest = TRUE,
    ordered_result = TRUE
  )]
} else {
  permA[, volume_stratum := factor("all")]
}

permA[, perm_stratum_A := interaction(
  time_stratum,
  volume_stratum,
  drop = TRUE
)]

obsA <- permA[, .(
  Dv = sum(final_AI_challenge)
), by = source_row]

T_obs <- sum(choose2(obsA$Dv))
V2_obs <- sum(obsA$Dv >= 2L)

permA[, video_gid := match(source_row, unique(source_row))]
G <- max(permA$video_gid)

strata_A <- split(
  seq_len(nrow(permA)),
  permA$perm_stratum_A
)

K_A <- vapply(
  strata_A,
  function(ii) sum(permA$final_AI_challenge[ii]),
  integer(1)
)

T_null <- numeric(CFG$permutations)
V2_null <- integer(CFG$permutations)

set.seed(CFG$seed + 101L)

for (b in seq_len(CFG$permutations)) {
  selected <- unlist(
    Map(function(ii, kk) {
      if (kk <= 0L) return(integer(0))
      if (kk >= length(ii)) return(ii)
      sample(ii, kk, replace = FALSE)
    }, strata_A, K_A),
    use.names = FALSE
  )

  kv <- tabulate(
    permA$video_gid[selected],
    nbins = G
  )

  T_null[b] <- sum(choose2(kv))
  V2_null[b] <- sum(kv >= 2L)

  if (b %% 500L == 0L) {
    message("[8/10] Permutation A: ", b, "/", CFG$permutations)
  }
}

pT <- (1 + sum(T_null >= T_obs)) / (CFG$permutations + 1)
pV <- (1 + sum(V2_null >= V2_obs)) / (CFG$permutations + 1)

perm_A_result <- data.table(
  statistic = c(
    "within_video_challenge_pairs",
    "videos_with_2plus_challenges"
  ),
  observed = c(T_obs, V2_obs),
  null_mean = c(mean(T_null), mean(V2_null)),
  null_sd = c(sd(T_null), sd(V2_null)),
  observed_to_null_ratio = c(
    T_obs / mean(T_null),
    V2_obs / mean(V2_null)
  ),
  p_upper = c(pT, pV),
  permutations = CFG$permutations
)

fwrite(
  perm_A_result,
  file.path(CFG$output_dir, "25_FINAL_COND_PERM_A.csv"),
  bom = TRUE
)

# B: A/S + C co-occurrence conditional on AI-provenance slots.
permB <- comments_main[
  final_AI_provenance &
    !is.na(final_stance) &
    !is.na(comment_time_utc)
]

permB[, year_stratum := factor(
  lubridate::year(comment_time_utc)
)]

obsB <- permB[, .(
  Dv = sum(final_stance %in% c("A", "S")),
  Cv = sum(final_stance == "C")
), by = source_row]

B_obs <- sum(obsB$Dv >= 1L & obsB$Cv >= 1L)

permB[, video_gid_B := match(
  source_row,
  unique(source_row)
)]
GB <- max(permB$video_gid_B)

strata_B <- split(
  seq_len(nrow(permB)),
  permB$year_stratum
)

B_null <- integer(CFG$permutations)

set.seed(CFG$seed + 202L)

for (b in seq_len(CFG$permutations)) {
  stance_perm <- permB$final_stance

  for (ii in strata_B) {
    stance_perm[ii] <- sample(
      stance_perm[ii],
      length(ii),
      replace = FALSE
    )
  }

  D_idx <- which(stance_perm %in% c("A", "S"))
  C_idx <- which(stance_perm == "C")

  Dv <- tabulate(
    permB$video_gid_B[D_idx],
    nbins = GB
  )
  Cv <- tabulate(
    permB$video_gid_B[C_idx],
    nbins = GB
  )

  B_null[b] <- sum(Dv >= 1L & Cv >= 1L)

  if (b %% 500L == 0L) {
    message("[9/10] Permutation B: ", b, "/", CFG$permutations)
  }
}

p_upper_B <- (
  1 + sum(B_null >= B_obs)
) / (CFG$permutations + 1)

p_lower_B <- (
  1 + sum(B_null <= B_obs)
) / (CFG$permutations + 1)

p_two_B <- min(
  1,
  2 * min(p_upper_B, p_lower_B)
)

perm_B_result <- data.table(
  statistic = "videos_with_challenge_and_counter_authentication",
  observed = B_obs,
  null_mean = mean(B_null),
  null_sd = sd(B_null),
  observed_to_null_ratio = B_obs / mean(B_null),
  p_upper = p_upper_B,
  p_two_sided = p_two_B,
  permutations = CFG$permutations,
  n_AI_provenance_comments = nrow(permB),
  n_AI_provenance_videos = uniqueN(permB$source_row)
)

fwrite(
  perm_B_result,
  file.path(CFG$output_dir, "26_FINAL_COND_PERM_B.csv"),
  bom = TRUE
)

# ==============================================================================
# 11. INTERACTIONAL UPTAKE
# ==============================================================================

if (isTRUE(CFG$run_interaction_models)) {
  cores <- parallel::detectCores(logical = TRUE)
  if (is.finite(cores) && cores > 1L) {
    fixest::setFixest_nthreads(
      max(1L, cores - 1L)
    )
  }

  ana <- comments_main[
    n_retrieved_comments >= CFG$min_comments_per_video_fe
  ]

  # Defensive derived variables.
  if (!"log_word_count" %in% names(ana)) {
    ana[, word_count := stringr::str_count(
      stringr::str_squish(text),
      "\\S+"
    )]
    ana[, log_word_count := log1p(word_count)]
  }

  ana[, like_count := as.numeric(like_count)]
  ana[, reply_count := as.numeric(reply_count)]
  ana[is.na(like_count), like_count := 0]
  ana[is.na(reply_count), reply_count := 0]

  ana[, log_like_count := log1p(like_count)]
  ana[, log_reply_count := log1p(reply_count)]

  time_control <- ""
  if (
    "log_hours_after_video" %in% names(ana) &&
      mean(!is.na(ana$log_hours_after_video)) >= .50
  ) {
    time_control <- " + log_hours_after_video"
  }

  f_like <- as.formula(paste0(
    "like_count ~ final_AI_challenge + log_word_count",
    time_control,
    " | source_row"
  ))

  f_reply <- as.formula(paste0(
    "reply_count ~ final_AI_challenge + log_word_count",
    time_control,
    " | source_row"
  ))

  m_like <- fixest::fepois(
    f_like,
    data = ana,
    cluster = ~source_row
  )
  m_reply <- fixest::fepois(
    f_reply,
    data = ana,
    cluster = ~source_row
  )

  ana[, final_discourse_type := factor(
    final_discourse_type,
    levels = c(
      "other",
      "AI_assertion",
      "AI_suspicion",
      "counter_authentication",
      "other_AI_provenance"
    )
  )]

  f_cat_like <- as.formula(paste0(
    "like_count ~ i(final_discourse_type, ref='other') + log_word_count",
    time_control,
    " | source_row"
  ))
  f_cat_reply <- as.formula(paste0(
    "reply_count ~ i(final_discourse_type, ref='other') + log_word_count",
    time_control,
    " | source_row"
  ))

  m_cat_like <- fixest::fepois(
    f_cat_like,
    data = ana,
    cluster = ~source_row
  )
  m_cat_reply <- fixest::fepois(
    f_cat_reply,
    data = ana,
    cluster = ~source_row
  )

  f_loglike <- as.formula(paste0(
    "log_like_count ~ final_AI_challenge + log_word_count",
    time_control,
    " | source_row"
  ))
  f_logreply <- as.formula(paste0(
    "log_reply_count ~ final_AI_challenge + log_word_count",
    time_control,
    " | source_row"
  ))

  m_loglike <- fixest::feols(
    f_loglike,
    data = ana,
    cluster = ~source_row
  )
  m_logreply <- fixest::feols(
    f_logreply,
    data = ana,
    cluster = ~source_row
  )

  interaction_models <- list(
    likes_ppml = m_like,
    replies_ppml = m_reply,
    category_likes_ppml = m_cat_like,
    category_replies_ppml = m_cat_reply,
    loglikes_ols = m_loglike,
    logreplies_ols = m_logreply
  )

  capture.output(
    fixest::etable(
      m_like,
      m_reply,
      m_cat_like,
      m_cat_reply,
      m_loglike,
      m_logreply
    ),
    file = file.path(
      CFG$output_dir,
      "27_FINAL_INTERACTION_MODELS.txt"
    )
  )

  tidy_models <- rbindlist(
    lapply(
      names(interaction_models),
      function(nm) {
        z <- data.table::as.data.table(
          broom::tidy(
            interaction_models[[nm]],
            conf.int = TRUE
          )
        )
        z[, model := nm]
        z
      }
    ),
    fill = TRUE
  )

  fwrite(
    tidy_models,
    file.path(
      CFG$output_dir,
      "27_FINAL_INTERACTION_MODELS_TIDY.csv"
    ),
    bom = TRUE
  )
}

# ==============================================================================
# 12. TIME COMPOSITION + FIGURES + PUBLICATION AUDIT
# ==============================================================================

monthly <- comments_main[
  !is.na(comment_month),
  .(
    comments = .N,
    videos = uniqueN(source_row),
    AI_challenges = sum(final_AI_challenge),
    AI_provenance = sum(final_AI_provenance)
  ),
  by = comment_month
][order(comment_month)]

monthly[, AI_challenges_per_10000 := (
  10000 * AI_challenges / comments
)]
monthly[, AI_provenance_per_10000 := (
  10000 * AI_provenance / comments
)]

fwrite(
  monthly,
  file.path(
    CFG$output_dir,
    "28_FINAL_MONTHLY_DESCRIPTIVE_COMPOSITION.csv"
  ),
  bom = TRUE
)

p1 <- ggplot(
  monthly,
  aes(
    x = comment_month,
    y = AI_challenges_per_10000
  )
) +
  geom_line() +
  geom_point() +
  labs(
    title = "AI-provenance challenges over time",
    subtitle = paste0(
      "Human-confirmed AI comments; descriptive corpus composition only"
    ),
    x = NULL,
    y = "AI challenges per 10,000 retrieved comments"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  file.path(
    CFG$output_dir,
    "Figure_1_FINAL_monthly_AI_challenges.png"
  ),
  p1,
  width = 10,
  height = 6,
  dpi = 300
)

plot_categories <- category_summary[
  final_discourse_type != "other"
]

p2 <- ggplot(
  plot_categories,
  aes(
    x = reorder(final_discourse_type, comments),
    y = comments
  )
) +
  geom_col() +
  coord_flip() +
  labs(
    title = "Human-confirmed AI-provenance discourse categories",
    x = NULL,
    y = "Number of comments"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  file.path(
    CFG$output_dir,
    "Figure_2_FINAL_AI_categories.png"
  ),
  p2,
  width = 9,
  height = 6,
  dpi = 300
)

p3 <- ggplot(
  data.table(T_null = T_null),
  aes(x = T_null)
) +
  geom_histogram(bins = 50) +
  geom_vline(
    xintercept = T_obs,
    linetype = 2
  ) +
  labs(
    title = "Conditional null distribution of within-video AI-challenge pairs",
    subtitle = paste0(
      "Observed = ",
      format(T_obs, big.mark = ",")
    ),
    x = "Permuted challenge-pair statistic",
    y = "Permutation count"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  file.path(
    CFG$output_dir,
    "Figure_3_FINAL_conditional_concentration.png"
  ),
  p3,
  width = 9,
  height = 6,
  dpi = 300
)

p4 <- ggplot(
  data.table(B_null = B_null),
  aes(x = B_null)
) +
  geom_histogram(bins = 40) +
  geom_vline(
    xintercept = B_obs,
    linetype = 2
  ) +
  labs(
    title = "Conditional null distribution of opposing AI-provenance stances",
    subtitle = paste0(
      "Observed co-occurrence videos = ",
      B_obs
    ),
    x = "Permuted A/S + C co-occurrence videos",
    y = "Permutation count"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  file.path(
    CFG$output_dir,
    "Figure_4_FINAL_stance_cooccurrence.png"
  ),
  p4,
  width = 9,
  height = 6,
  dpi = 300
)

publication_audit <- data.table(
  item = c(
    "analysis_status",
    "main_language_comments",
    "original_human_gold_rows",
    "original_human_gold_AI",
    "new_retrieved_candidates_reviewed",
    "new_candidate_confirmed_AI",
    "negative_audit_sample_n",
    "negative_audit_confirmed_AI",
    "estimated_remaining_missed_AI_in_unreviewed_negatives",
    "estimated_final_retrieval_recall",
    "final_human_confirmed_AI_comments",
    "final_AI_assertions",
    "final_AI_suspicions",
    "final_counter_authentication",
    "final_AI_challenges",
    "cond_perm_A_observed_pairs",
    "cond_perm_A_null_mean_pairs",
    "cond_perm_A_p_upper",
    "cond_perm_B_observed_cooccurrence",
    "cond_perm_B_null_mean",
    "cond_perm_B_p_upper",
    "cond_perm_B_p_two_sided"
  ),
  value = as.character(c(
    "human_confirmed_AI_corpus_with_negative_audit_passed",
    nrow(comments_main),
    nrow(gold_ml),
    existing_gold_AI,
    nrow(cand_done),
    new_confirmed_AI,
    nrow(neg_done),
    audit_confirmed_AI,
    estimated_missed_AI,
    estimated_final_recall,
    final_summary$n_AI_provenance,
    final_summary$n_AI_assertion,
    final_summary$n_AI_suspicion,
    final_summary$n_counter_authentication,
    final_summary$n_AI_challenge,
    perm_A_result[
      statistic == "within_video_challenge_pairs",
      observed
    ],
    perm_A_result[
      statistic == "within_video_challenge_pairs",
      null_mean
    ],
    perm_A_result[
      statistic == "within_video_challenge_pairs",
      p_upper
    ],
    perm_B_result$observed,
    perm_B_result$null_mean,
    perm_B_result$p_upper,
    perm_B_result$p_two_sided
  ))
)

fwrite(
  publication_audit,
  file.path(
    CFG$output_dir,
    "29_FINAL_PUBLICATION_AUDIT.csv"
  ),
  bom = TRUE
)

writeLines(
  c(
    "============================================================",
    "AI PROVENANCE V3.5.5 COMPLETED",
    "============================================================",
    "Measurement strategy: model-assisted retrieval + human confirmation",
    paste0(
      "Final human-confirmed AI comments: ",
      final_summary$n_AI_provenance
    ),
    paste0(
      "Estimated final retrieval recall: ",
      sprintf("%.3f", estimated_final_recall)
    ),
    paste0(
      "AI assertions: ",
      final_summary$n_AI_assertion
    ),
    paste0(
      "AI suspicions: ",
      final_summary$n_AI_suspicion
    ),
    paste0(
      "Counter-authentication: ",
      final_summary$n_counter_authentication
    ),
    paste0(
      "AI challenges (A+S): ",
      final_summary$n_AI_challenge
    ),
    "",
    "Interpretation boundaries:",
    "- All core AI-provenance labels are human-confirmed.",
    "- Unreviewed predicted negatives are treated as non-AI only after the stratified negative audit passes.",
    "- Likes/replies are interactional uptake, not belief.",
    "- Concentration is not contagion.",
    "- Co-occurrence is not a reply relation.",
    "- Monthly patterns are descriptive corpus composition, not TikTok-wide prevalence trends."
  ),
  file.path(
    CFG$output_dir,
    "00_FINAL_RUN_SUMMARY_V3_5_4.txt"
  )
)

capture.output(
  sessionInfo(),
  file = file.path(
    CFG$output_dir,
    "30_sessionInfo_V3_5_4.txt"
  )
)

message("============================================================")
message("V3.5.5 FINAL ANALYSIS COMPLETED.")
message(
  "Key output: ",
  file.path(
    CFG$output_dir,
    "00_FINAL_RUN_SUMMARY_V3_5_4.txt"
  )
)
message("============================================================")
