
# ==============================================================================
# AI Provenance — 4-row count reconciliation
# Purpose: explain 1,110,048 (current cache) vs 1,110,044 (old final outputs)
# No model is refit.
# ==============================================================================

suppressPackageStartupMessages(library(data.table))

OUT <- "AI_Provenance_Submission_Audit"
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)

find_first <- function(paths) {
  z <- paths[file.exists(paths)]
  if (!length(z)) return(NA_character_)
  z[[1]]
}

cache <- find_first(c(
  "AI_Provenance_V3_outputs/comments_prelabelled_v3.rds",
  "AI_Provenance_V2_outputs/comments_coded_v2.rds",
  "comments_prelabelled_v3.rds",
  "comments_coded_v2.rds"
))
pred_path <- find_first(c(
  "AI_Provenance_V3_5_outputs/15_AI_retrieval_scores_v3_5.csv",
  "15_AI_retrieval_scores_v3_5.csv"
))
old_audit_path <- find_first(c(
  "AI_Provenance_V3_5_outputs/09_AI_candidate_retrieval_audit.csv",
  "09_AI_candidate_retrieval_audit.csv"
))
old_summary_path <- find_first(c(
  "AI_Provenance_V3_5_outputs/20_FINAL_AI_LABEL_SUMMARY.csv",
  "20_FINAL_AI_LABEL_SUMMARY.csv"
))

if (is.na(cache)) stop("Cannot find comments cache.")

comments <- as.data.table(readRDS(cache))
comments[, comment_key := as.character(comment_key)]
en <- comments[
  !is.na(comment_language) &
    nzchar(trimws(as.character(comment_language))) &
    tolower(trimws(as.character(comment_language))) == "en"
]

dup_key <- en[duplicated(comment_key) | duplicated(comment_key, fromLast = TRUE)]
dup_pair <- en[
  duplicated(paste(comment_key, source_row, sep = "::")) |
    duplicated(paste(comment_key, source_row, sep = "::"), fromLast = TRUE)
]

summary <- data.table(
  item = c(
    "English rows in current cache",
    "Unique comment_key in English cache",
    "Unique comment_key + source_row pairs in English cache",
    "Rows involved in duplicated comment_key",
    "Rows involved in duplicated comment_key+source_row"
  ),
  N = c(
    nrow(en),
    uniqueN(en$comment_key),
    uniqueN(paste(en$comment_key, en$source_row, sep = "::")),
    nrow(dup_key),
    nrow(dup_pair)
  )
)

fwrite(summary, file.path(OUT, "10_count_reconciliation_summary.csv"), bom = TRUE)
if (nrow(dup_key)) {
  fwrite(
    dup_key,
    file.path(OUT, "11_duplicate_English_comment_keys.csv"),
    bom = TRUE
  )
}
if (nrow(dup_pair)) {
  fwrite(
    dup_pair,
    file.path(OUT, "12_duplicate_English_key_source_pairs.csv"),
    bom = TRUE
  )
}

# Compare with V3.5 prediction cache.
if (!is.na(pred_path)) {
  pred <- fread(pred_path, select = c("comment_key","source_row"))
  pred[, comment_key := as.character(comment_key)]

  cache_keys <- unique(en[, .(comment_key, source_row)])
  pred_keys <- unique(pred[, .(comment_key, source_row)])

  missing_in_pred <- fsetdiff(cache_keys, pred_keys)
  extra_in_pred <- fsetdiff(pred_keys, cache_keys)

  pred_summary <- data.table(
    item = c(
      "prediction cache rows",
      "prediction cache unique key+source pairs",
      "English cache unique key+source pairs",
      "English cache pairs missing from prediction cache",
      "prediction pairs not present in English cache"
    ),
    N = c(
      nrow(pred),
      nrow(pred_keys),
      nrow(cache_keys),
      nrow(missing_in_pred),
      nrow(extra_in_pred)
    )
  )
  fwrite(
    pred_summary,
    file.path(OUT, "13_prediction_cache_reconciliation.csv"),
    bom = TRUE
  )
  if (nrow(missing_in_pred)) {
    z <- merge(
      missing_in_pred,
      en,
      by = c("comment_key","source_row"),
      all.x = TRUE
    )
    fwrite(
      z,
      file.path(OUT, "14_rows_missing_from_prediction_cache.csv"),
      bom = TRUE
    )
  }
  if (nrow(extra_in_pred)) {
    fwrite(
      extra_in_pred,
      file.path(OUT, "15_prediction_rows_not_in_current_English_cache.csv"),
      bom = TRUE
    )
  }
}

# Read old reported counts so all versions appear in one file.
reported <- list()
if (!is.na(old_audit_path)) {
  a <- fread(old_audit_path)
  reported[["old_candidate_audit_main_language_comments"]] <-
    a$main_language_comments[1]
}
if (!is.na(old_summary_path)) {
  s <- fread(old_summary_path)
  reported[["old_final_summary_n_comments"]] <- s$n_comments[1]
}

if (length(reported)) {
  rep_dt <- data.table(
    item = names(reported),
    N = as.numeric(unlist(reported))
  )
  fwrite(
    rep_dt,
    file.path(OUT, "16_old_reported_counts.csv"),
    bom = TRUE
  )
}

message("Reconciliation complete. Check files 10–16 in: ", normalizePath(OUT))
