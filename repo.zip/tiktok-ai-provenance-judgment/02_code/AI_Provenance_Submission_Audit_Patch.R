
# ==============================================================================
# AI Provenance Study — Submission Audit Patch
# Purpose:
#   1) report English vs missing-language composition;
#   2) report language composition of the 1,317 confirmed AI comments and core 216;
#   3) fit strict-English sensitivity for the core A/C reason comparison;
#   4) explain the 350-row interaction-model gap;
#   5) report final retained video counts / clusters;
#   6) run extreme-interaction-value sensitivity checks.
#
# Run from the same project directory that contains the V3.5 output folders.
# This script reuses comments_prelabelled_v3.rds or comments_coded_v2.rds.
# It does NOT retrain the retrieval classifier.
# ==============================================================================

suppressPackageStartupMessages({
  library(data.table)
  library(fixest)
})

OUT <- "AI_Provenance_Submission_Audit"
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)

find_first <- function(paths) {
  z <- paths[file.exists(paths)]
  if (!length(z)) return(NA_character_)
  z[[1]]
}

cache <- find_first(c(
  "AI_Provenance_V3_outputs/comments_prelabelled_v3.rds",
  "AI_Provenance_V2_outputs/comments_coded_v2.rds",
  "comments_prelabelled_v3.rds",
  "comments_coded_v2.rds"
))
if (is.na(cache)) stop("Cannot find parsed/prelabelled comment cache.")

gold_path <- find_first(c(
  "HUMAN_ADJUDICATED_FINAL.csv",
  "AI_Provenance_V3_5_outputs/HUMAN_ADJUDICATED_FINAL.csv",
  "AI_Provenance_V3_outputs/HUMAN_ADJUDICATED_FINAL.csv"
))
cand_path <- find_first(c(
  "AI_CANDIDATE_REVIEW_COMPLETED.csv",
  "AI_CANDIDATE_REVIEW_COMPLETED(1).csv",
  "AI_Provenance_V3_5_outputs/AI_CANDIDATE_REVIEW_COMPLETED.csv"
))
neg_path <- find_first(c(
  "AI_NEGATIVE_AUDIT_COMPLETED.csv",
  "AI_NEGATIVE_AUDIT_COMPLETED(1).csv",
  "AI_Provenance_V3_5_outputs/AI_NEGATIVE_AUDIT_COMPLETED.csv"
))
if (any(is.na(c(gold_path, cand_path, neg_path)))) {
  stop("Cannot find one or more completed human-review files.")
}

comments <- as.data.table(readRDS(cache))
comments[, comment_key := as.character(comment_key)]

# ------------------------------------------------------------------
# 1. Main-language composition
# ------------------------------------------------------------------
comments[, lang_group := fcase(
  !is.na(comment_language) & nzchar(trimws(as.character(comment_language))) &
    tolower(trimws(as.character(comment_language))) == "en",
  "English",
  is.na(comment_language) | !nzchar(trimws(as.character(comment_language))),
  "Missing_or_blank",
  default = "Other_language"
)]

comments_main <- comments[lang_group %in% c("English", "Missing_or_blank")]

lang_overall <- comments[, .N, by = lang_group][order(-N)]
lang_main <- comments_main[, .N, by = lang_group][order(-N)]

# ------------------------------------------------------------------
# 2. Reconstruct final human-confirmed AI corpus
# ------------------------------------------------------------------
gold <- fread(gold_path, encoding = "UTF-8")
gold[, comment_key := as.character(comment_key)]
gold_pos <- gold[
  provenance_relevant_final == 1L & technology_final == "AI",
  .(
    comment_key,
    source_row,
    stance_final,
    primary_reason_final,
    reason_type_final,
    label_source = "gold"
  )
]

cand <- fread(cand_path, encoding = "UTF-8")
cand[, comment_key := as.character(comment_key)]
cand_pos <- cand[
  AI_provenance_final == 1L,
  .(
    comment_key,
    source_row,
    stance_final,
    primary_reason_final,
    reason_type_final,
    label_source = "candidate"
  )
]

neg <- fread(neg_path, encoding = "UTF-8")
neg[, comment_key := as.character(comment_key)]
neg_pos <- neg[
  AI_provenance_final == 1L,
  .(
    comment_key,
    source_row,
    stance_final,
    primary_reason_final,
    reason_type_final,
    label_source = "negative_audit"
  )
]

final_ai <- unique(rbindlist(
  list(gold_pos, cand_pos, neg_pos),
  fill = TRUE
), by = "comment_key")

lang_lookup <- comments[, .(
  comment_key,
  source_row_corpus = source_row,
  lang_group,
  comment_language
)]

final_ai <- merge(
  final_ai,
  lang_lookup,
  by = "comment_key",
  all.x = TRUE
)

final_lang <- final_ai[, .N, by = lang_group][order(-N)]

# Core A/C sample: videos containing both A and C
ac <- final_ai[stance_final %in% c("A", "C")]
core_video <- ac[
  , .(has_A = any(stance_final == "A"),
      has_C = any(stance_final == "C")),
  by = source_row
][has_A & has_C, source_row]

core216 <- ac[source_row %in% core_video]
core_lang <- core216[, .N, by = lang_group][order(-N)]

# ------------------------------------------------------------------
# 3. Strict-English core sensitivity
# ------------------------------------------------------------------
core_en <- core216[lang_group == "English"]

strict_en_summary <- core_en[
  , .(
    n = .N,
    reason_n = sum(primary_reason_final == 1L, na.rm = TRUE),
    reason_rate = mean(primary_reason_final == 1L, na.rm = TRUE)
  ),
  by = stance_final
]

strict_en_model <- NULL
strict_en_tidy <- data.table()
if (
  nrow(core_en) >= 20L &&
  uniqueN(core_en$source_row) >= 10L &&
  all(c("A","C") %in% unique(core_en$stance_final))
) {
  # Require within-video A/C overlap after strict-English filtering.
  keep_v <- core_en[
    , .(has_A = any(stance_final == "A"),
        has_C = any(stance_final == "C")),
    by = source_row
  ][has_A & has_C, source_row]

  d <- core_en[source_row %in% keep_v]
  if (nrow(d) >= 20L && uniqueN(d$source_row) >= 10L) {
    d[, C_indicator := as.integer(stance_final == "C")]
    strict_en_model <- feols(
      primary_reason_final ~ C_indicator | source_row,
      data = d,
      cluster = ~ source_row
    )
    ct <- as.data.table(coeftable(strict_en_model), keep.rownames = "term")
    setnames(ct, c("Estimate","Std. Error","t value","Pr(>|t|)"),
             c("estimate","std_error","statistic","p_value"))
    ct[, `:=`(
      n = nobs(strict_en_model),
      videos = uniqueN(d$source_row)
    )]
    strict_en_tidy <- ct
  }
}

# ------------------------------------------------------------------
# 4. Reconstruct final discourse labels in the 1.11m analysis corpus
# ------------------------------------------------------------------
comments_main[, final_AI_provenance := FALSE]
comments_main[, final_stance := NA_character_]
comments_main[, final_reason := NA_integer_]
comments_main[, final_reason_type := NA_character_]

idx <- match(final_ai$comment_key, comments_main$comment_key)
ok <- !is.na(idx)
comments_main[
  idx[ok],
  `:=`(
    final_AI_provenance = TRUE,
    final_stance = final_ai$stance_final[ok],
    final_reason = final_ai$primary_reason_final[ok],
    final_reason_type = final_ai$reason_type_final[ok]
  )
]

comments_main[, final_AI_challenge := final_stance %in% c("A","S")]
comments_main[, final_discourse_type := fcase(
  final_stance == "A", "AI_assertion",
  final_stance == "S", "AI_suspicion",
  final_stance == "C", "non_AI_provenance_claim",
  final_AI_provenance, "other_AI_provenance",
  default = "other"
)]

# ------------------------------------------------------------------
# 5. Explain model sample flow and recover retained fixed-effect counts
# ------------------------------------------------------------------
if (!"n_retrieved_comments" %in% names(comments_main)) {
  comments_main[, n_retrieved_comments := .N, by = source_row]
}
if (!"log_word_count" %in% names(comments_main)) {
  comments_main[, word_count := lengths(strsplit(trimws(text), "\\s+"))]
  comments_main[, log_word_count := log1p(word_count)]
}
if (!"log_hours_after_video" %in% names(comments_main)) {
  stop("Cache lacks log_hours_after_video; use the same cache used for V3.5 final models.")
}

comments_main[, like_count := as.numeric(like_count)]
comments_main[, reply_count := as.numeric(reply_count)]
comments_main[is.na(like_count), like_count := 0]
comments_main[is.na(reply_count), reply_count := 0]

ana <- comments_main[n_retrieved_comments >= 2L]

sample_flow <- data.table(
  stage = c(
    "main_language_comments",
    "removed_before_models_single_retrieved_comment_video",
    "eligible_before_FE_model",
    "missing_log_word_count",
    "missing_log_hours_after_video"
  ),
  N = c(
    nrow(comments_main),
    nrow(comments_main) - nrow(ana),
    nrow(ana),
    sum(is.na(ana$log_word_count)),
    sum(is.na(ana$log_hours_after_video))
  )
)

f_like <- like_count ~ final_AI_challenge + log_word_count + log_hours_after_video | source_row
f_reply <- reply_count ~ final_AI_challenge + log_word_count + log_hours_after_video | source_row

m_like <- fepois(f_like, data = ana, cluster = ~ source_row)
m_reply <- fepois(f_reply, data = ana, cluster = ~ source_row)

ana[, log_like_count := log1p(like_count)]
ana[, log_reply_count := log1p(reply_count)]
m_loglike <- feols(
  log_like_count ~ final_AI_challenge + log_word_count + log_hours_after_video | source_row,
  data = ana, cluster = ~ source_row
)
m_logreply <- feols(
  log_reply_count ~ final_AI_challenge + log_word_count + log_hours_after_video | source_row,
  data = ana, cluster = ~ source_row
)

model_info <- data.table(
  model = c("likes_PPML","replies_PPML","loglikes_OLS","logreplies_OLS"),
  nobs = c(nobs(m_like), nobs(m_reply), nobs(m_loglike), nobs(m_logreply)),
  retained_video_FE = c(
    length(fixef(m_like)$source_row),
    length(fixef(m_reply)$source_row),
    length(fixef(m_loglike)$source_row),
    length(fixef(m_logreply)$source_row)
  )
)

# ------------------------------------------------------------------
# 6. Extreme-interaction-value sensitivity
# ------------------------------------------------------------------
run_trim <- function(dt, outcome, trim_q) {
  cutoff <- quantile(dt[[outcome]], probs = trim_q, na.rm = TRUE, names = FALSE)
  d <- dt[get(outcome) <= cutoff]
  if (outcome == "like_count") {
    mod <- fepois(
      like_count ~ final_AI_challenge + log_word_count + log_hours_after_video | source_row,
      data = d, cluster = ~ source_row
    )
  } else {
    mod <- fepois(
      reply_count ~ final_AI_challenge + log_word_count + log_hours_after_video | source_row,
      data = d, cluster = ~ source_row
    )
  }
  ct <- as.data.table(coeftable(mod), keep.rownames = "term")
  row <- ct[term == "final_AI_challengeTRUE"]
  data.table(
    outcome = outcome,
    retained_quantile = trim_q,
    cutoff = cutoff,
    nobs = nobs(mod),
    retained_video_FE = length(fixef(mod)$source_row),
    estimate = row[["Estimate"]],
    std_error = row[["Std. Error"]],
    p_value = row[["Pr(>|t|)"]]
  )
}

extreme_sens <- rbindlist(list(
  run_trim(ana, "like_count", .999),
  run_trim(ana, "like_count", .99),
  run_trim(ana, "reply_count", .999),
  run_trim(ana, "reply_count", .99)
))

# ------------------------------------------------------------------
# Write outputs
# ------------------------------------------------------------------
fwrite(lang_overall, file.path(OUT, "01_language_all_parsed_comments.csv"), bom=TRUE)
fwrite(lang_main, file.path(OUT, "02_language_main_analysis_corpus.csv"), bom=TRUE)
fwrite(final_lang, file.path(OUT, "03_language_final_1317_AI_comments.csv"), bom=TRUE)
fwrite(core_lang, file.path(OUT, "04_language_core216.csv"), bom=TRUE)
fwrite(strict_en_summary, file.path(OUT, "05_strict_English_core_descriptives.csv"), bom=TRUE)
fwrite(strict_en_tidy, file.path(OUT, "06_strict_English_core_FE.csv"), bom=TRUE)
fwrite(sample_flow, file.path(OUT, "07_interaction_model_sample_flow.csv"), bom=TRUE)
fwrite(model_info, file.path(OUT, "08_interaction_model_retained_video_FE.csv"), bom=TRUE)
fwrite(extreme_sens, file.path(OUT, "09_extreme_interaction_sensitivity.csv"), bom=TRUE)

capture.output(
  list(
    cache = cache,
    language_main = lang_main,
    final_AI_language = final_lang,
    core216_language = core_lang,
    strict_English_descriptives = strict_en_summary,
    strict_English_FE = strict_en_tidy,
    interaction_sample_flow = sample_flow,
    model_info = model_info,
    extreme_sensitivity = extreme_sens
  ),
  file = file.path(OUT, "00_SUBMISSION_AUDIT_SUMMARY.txt")
)

message("Done. Outputs written to: ", normalizePath(OUT))
