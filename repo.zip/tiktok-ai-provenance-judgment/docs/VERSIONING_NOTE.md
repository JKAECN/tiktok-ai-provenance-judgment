# Versioning note

Two analysis layers are intentionally distinguished.

1. **Frozen full-corpus pipeline (V3.5.5).**  
   Model-assisted retrieval, negative-audit, full-corpus conditional permutation, and interaction outputs were produced from the frozen V3.5.5 corpus/prediction cache. The frozen main-analysis count is 1,110,044 comments.

2. **Post-review core A/C reliability audit.**  
   Fifty-six later core comments received an independent second coding. Ten disagreements were resolved with fixed coding rules. One previously A-coded comment was adjudicated to X, and one A comment gained an explicit original-source reason. The core A/C comparison therefore changed from 216 to 215 comments across the same 48 videos.

Because this public repository does not contain the complete 57,931-video raw/cache data, the full-corpus permutation and interaction models were not retrospectively re-run after that one A→X core adjudication. Their filenames are explicitly marked `frozen_V3_5_5`.

This separation prevents a later core reliability audit from being silently represented as a full-corpus rerun.
