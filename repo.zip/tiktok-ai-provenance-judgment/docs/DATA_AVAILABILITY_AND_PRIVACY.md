# Data availability and privacy

This repository intentionally does **not** redistribute the raw TikTok comment corpus.

Excluded materials include usernames and account identifiers, comment/video IDs, direct links, verbatim comment text from the 56-comment recheck, video descriptions tied to individual comments, and the raw 57,931-video / 2,737,540-comment source archive.

The public package contains derived, aggregate, or de-identified supplementary materials sufficient to document the coding, retrieval, audit, reliability, sensitivity, clustering, and interaction analyses without exposing identifiable platform users.

The 56-comment second-coder and adjudication files use anonymous `review_id` values only. The 48-video core diagnostics use anonymous `video_cluster_id` values that are not mapped back to the original internal `source_row`.

Researchers seeking access to restricted/raw data should follow the permissions and platform/data-source conditions governing the original dataset. No raw-data sharing right is implied by this repository.
