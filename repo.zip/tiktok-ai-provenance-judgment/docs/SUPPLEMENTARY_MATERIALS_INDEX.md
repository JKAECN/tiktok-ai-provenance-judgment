# Supplementary materials index

| Item | Repository location |
|---|---|
| Coding manual | `01_codebook/` |
| Final AI-specific retrieval/analysis script | `02_code/AI_Provenance_AllInOne_V3_5_5.R` |
| Submission-audit and count-reconciliation scripts | `02_code/` |
| Combined model+rule OOF retrieval performance | `03_retrieval_audit/combined_model_rule_OOF_summary.csv` |
| Core A/C and explicit-reason confusion matrices | `04_core_reliability/` |
| 56-comment second-coder blind recheck, de-identified | `04_core_reliability/core56_second_coder_results_deidentified.csv` |
| 10 rule-based adjudications, de-identified | `04_core_reliability/core56_rule_based_adjudication_deidentified.csv` |
| Final reliability summary | `04_core_reliability/core56_final_reliability.csv` |
| Updated 215-comment FE / equal-video / LOO / wild-cluster summary | `05_core_analysis/core215_FE_sensitivity_summary.csv` |
| Detailed 48-video diagnostics | `05_core_analysis/core215_48video_diagnostics_deidentified.csv` |
| Detailed leave-one-video-out results | `05_core_analysis/core215_leave_one_video_out_deidentified.csv` |
| Negative-audit population and uncertainty | `06_negative_audit/` |
| Clustering contribution diagnostic | `07_clustering/clustering_contribution_diagnostic.csv` |
| Frozen conditional permutation outputs | `07_clustering/conditional_permutation_*_frozen_V3_5_5.csv` |
| Language composition and four-record cache reconciliation | `08_language_and_sample_audit/` |
| Frozen interaction models | `09_interaction_sensitivity/final_interaction_models_frozen_V3_5_5.csv` |
| Retained video fixed-effect counts | `09_interaction_sensitivity/interaction_model_retained_video_FE_normalized_cache_audit.csv` |
| 0.1% and 1% extreme-value trimming sensitivity | `09_interaction_sensitivity/extreme_interaction_trim_sensitivity.csv` |
